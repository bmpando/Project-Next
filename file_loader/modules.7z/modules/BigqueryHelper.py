class BigqueryHelper:
    def __init__(self, chat_url, event_id, project_id, file_name, error_bucket, message):

